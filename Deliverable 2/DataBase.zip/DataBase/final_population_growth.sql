-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: final
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `population_growth`
--

DROP TABLE IF EXISTS `population_growth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `population_growth` (
  `customer_state` text,
  `pop_year` year DEFAULT NULL,
  `pop_growth_rate` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `population_growth`
--

LOCK TABLES `population_growth` WRITE;
/*!40000 ALTER TABLE `population_growth` DISABLE KEYS */;
INSERT INTO `population_growth` VALUES ('SP',2016,-0.019),('RJ',2016,-0.029),('MG',2016,0.051),('RS',2016,-0.047),('PR',2016,0.005),('RN',2016,-0.023),('DF',2016,0.055),('SC',2016,-0.002),('MS',2016,0.026),('BA',2016,-0.029),('PB',2016,0.061),('PA',2016,-0.03),('ES',2016,0.051),('CE',2016,0.065),('AM',2016,-0.004),('PE',2016,0.06),('PI',2016,0.058),('MA',2016,0.028),('GO',2016,0.039),('AL',2016,0.039),('MT',2016,-0.047),('SE',2016,-0.035),('RO',2016,0.016),('TO',2016,-0.016),('SP',2017,0.005),('RJ',2017,-0.041),('MG',2017,-0.005),('RS',2017,-0.035),('PR',2017,-0.012),('RN',2017,0.018),('DF',2017,0.015),('SC',2017,0.052),('MS',2017,0.065),('BA',2017,-0.022),('PB',2017,-0.048),('PA',2017,-0.006),('ES',2017,-0.01),('CE',2017,0),('AM',2017,-0.033),('PE',2017,0.001),('PI',2017,0.007),('MA',2017,-0.022),('GO',2017,0.035),('AL',2017,0.033),('MT',2017,0.008),('SE',2017,-0.042),('RO',2017,0.066),('TO',2017,0.045),('SP',2018,0.017),('RJ',2018,0.055),('MG',2018,-0.001),('RS',2018,-0.027),('PR',2018,-0.02),('RN',2018,-0.048),('DF',2018,-0.024),('SC',2018,0.009),('MS',2018,0.009),('BA',2018,-0.039),('PB',2018,0.037),('PA',2018,-0.014),('ES',2018,-0.044),('CE',2018,0.051),('AM',2018,-0.013),('PE',2018,0.022),('PI',2018,0.062),('MA',2018,0.025),('GO',2018,0.036),('AL',2018,0.023),('MT',2018,0.014),('SE',2018,0.014),('RO',2018,-0.043),('TO',2018,0.015);
/*!40000 ALTER TABLE `population_growth` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-01 13:23:14
